package eStore;

public class Employee {
String emplyeeName;
String employeeID;
String employeePrivilege;
String password;
public String getEmplyeeName() {
	return emplyeeName;
}
public void setEmplyeeName(String emplyeeName) {
	this.emplyeeName = emplyeeName;
}
public String getEmployeeID() {
	return employeeID;
}
public void setEmployeeID(String employeeID) {
	this.employeeID = employeeID;
}
public String getEmployeePrivilege() {
	return employeePrivilege;
}
public void setEmployeePrivilege(String employeePrivilege) {
	this.employeePrivilege = employeePrivilege;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

}